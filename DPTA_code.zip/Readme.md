
# Introducton of some file and folders
### Folders
*exp_params*: All experimental hyperparameters in six datasets, some parameters are explained in the supplementary material. In addition to the  common parameters in most methods include the learning rate, combine weights of loss, batch_size, cosine scheduler params for optimizer ... etc., **DPTA's own parameter only include the Top-K**.<br>
*radam*: Programming implementation of Radam optimizer. The optimizer is very insensitive to the learning rate, thus reducing the time we spend tuning the learning rate compared to SGD. <br>
*logs*: The log file that stores the running information of codes. <br>

### Files
*main.py*: The main file of DPTA for a class-incremental learning process (training and test) on the specified dataset. <br>
*Drawtsne.ipynb*: A example of how to draw t-SNE figures similar to ours in paper. <br>

# Reproducibility

### How to reproduce the DPTA
Make sure the './make_dataset/dataset/' has the corresponding dataset, then run **python main.py** , where the main.py including the training and test process of DPTA, and the results are proposed as decimal form, not a percentage.

**The result may vary with the pytorch version.**  

### Simple way to verification
Before we upload the code, we run **main.py** on six datasets again and the results can be found in './logs'. Due to the inherent randomness of deep learning, the results are somewhat different from table1 (abs difference < 0.1%).

# Dataset downloads
As each dataset is too large totransfer it directly in the code. Here is how to download them:
1. CIFAR-100: use torchvision to automaticly downloads.
2. CARS: cars cannot be downloaded directly in pytorch, the train and test data can be found in kaggle. Our code will propose the devkit and annos files in 'make_dataset/dataset/stanford_cars'.
3. Other Dataset: download in GitHuB, Kaggle or other place.


# Dependencies
Pytorch == 2.41  <br>
torchvision == 0.15.2 <br>
timm == 0.6.12 <br>
tqdm <br>
numpy <br>
scipy <br>
easydict <br>

We successfully ran this code on pytorch1.8, so all versions of pytorch above 1.8 are compatible in theory.

# Permissions
This code **can only be used** for the verification of experimental results in our paper, and any other use is prohibited until it is officially posted on GitHub.